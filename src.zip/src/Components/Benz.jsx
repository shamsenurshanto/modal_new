

const Benz = () => {
    return (
        <div className="mt-4">
          <p>skdj</p>
        </div>
      );
};

export default Benz;
