import React from 'react';
import { Dropdown } from 'bootstrap';

import Button from 'react-bootstrap/Button';
import ButtonGroup from 'react-bootstrap/esm/ButtonGroup';
import Form from 'react-bootstrap/Form';

import SplitBasicExample from '../SplitBasicExample/SplitBasicExample';

const Forms = (props) => {
    console.log(props.name)
    return (
        <div>
            
        </div>
    );
};

export default Forms;