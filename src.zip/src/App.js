import logo from './logo.svg';
import './App.css';
import MyModal from './Components/MyModal/MyModal';
import 'bootstrap/dist/css/bootstrap.css';
import Products from './Components/Products';
import Login from './Components/Login/Login';

import Button from "@mui/material/Button";



function App() {
  return (
    <div className="App ">
      <div className=''>
   
      {/* <Button variant="contained">Hello World</Button> */}
      </div>
    
      <Login></Login>

      {/* <MyModal></MyModal> */}
    </div>
  );
}

export default App;
